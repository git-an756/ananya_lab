package happybeginning;
mport java.util.Arrays;
import java.util.List;

public class BookDaoImpl {@Override
	public List<String> getBooks() {
	log();
	return null;
}

public void log() {
	System.out.println("logging in action...");
}

}
