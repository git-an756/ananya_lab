package happybeginning;

public interface BookService {

}
