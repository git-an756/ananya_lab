package happybeginning;

public interface BookDao {
	public List<String> getBooks();

}
